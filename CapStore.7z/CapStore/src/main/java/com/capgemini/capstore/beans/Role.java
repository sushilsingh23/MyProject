package com.capgemini.capstore.beans;

public enum Role {
	Customer,Admin,Merchant
}

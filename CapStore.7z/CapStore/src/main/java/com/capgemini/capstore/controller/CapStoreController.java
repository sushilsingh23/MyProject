package com.capgemini.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Address;
import com.capgemini.capstore.beans.Customer;

import com.capgemini.capstore.service.IShippingDetailService;

@RestController
public class CapStoreController {
	@Autowired
	 IShippingDetailService shippingService;
	static Customer customer;
	static Address newAdd;
	@GetMapping("/address/{custId}")
	public ResponseEntity<Address> getAllAddress(@PathVariable("custId") Integer custId){
		Address address=shippingService.findAll(custId);
	 if (address==null)
		 return new ResponseEntity<Address>(HttpStatus.NOT_FOUND);
	 return new ResponseEntity<Address>(address,HttpStatus.OK);
	}
	@PostMapping("/address/{custId}")
	public ResponseEntity<Address> addAddress(@PathVariable("custId") Integer custId,@RequestBody Address address){
		customer=shippingService.findCustomer(custId);
		shippingService.addAddress(address);
		newAdd=address;
		return new ResponseEntity<Address>(address,HttpStatus.OK);
	}
	
}

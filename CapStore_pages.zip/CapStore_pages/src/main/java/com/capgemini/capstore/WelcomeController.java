package com.capgemini.capstore;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.User;

@Controller
public class WelcomeController {
	
	@Bean
	public RestTemplate restTemplate() {
	    return new RestTemplate();
	}
	
	@Autowired
	RestTemplate rest;

	// inject via application.properties
	/*
	 * @Value("${welcome.message:test}") private String message = "Hello World";
	 * 
	 * @RequestMapping("/") public String welcome(Map<String, Object> model) {
	 * model.put("message", this.message); return "welcome"; }
	 */

	@RequestMapping("/")
	public String getResponse(ModelMap map){
			
	
		return "Home";
		
		}
	
	@RequestMapping(value="/Login")
	public String getSignUp(HttpServletRequest request) {
		System.out.println("hi");
		return "Login";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.POST,produces = "application/json")
	public String enterSignUpDetails(HttpServletRequest request) {

		User user = new User();
		String email = request.getParameter("email");
		user.setEmailId(email);
		String password = request.getParameter("password");
		user.setPassword(password);
		String role = request.getParameter("a3");
		System.out.println(user);
		user.setRole(role);
		HttpSession session  = request.getSession(true);
		session.setAttribute("user", user);
		String str = rest.postForObject("http://localhost:8088/logIn", user, String.class);
		return str;
	}
	
	@RequestMapping(value = "/Ask")
	public String getSignUpDetails() {
		
		return "Ask";
	}
	@RequestMapping(value = "/ForgotPassword")
	public String forgotPassword() {
		
		return "ForgotPassword";
	}
	
	@RequestMapping(value = "/ForgotPasswordd", method = RequestMethod.POST,produces = "application/json")
	public String afterForgotPassword(HttpServletRequest request) {
		
		User user = new User();
		String email = request.getParameter("n4");
		String securityQuestion = request.getParameter("a4");
		String securityAnswer = request.getParameter("n2");
		user.setEmailId(email);
		user.setSecurityAnswer(securityAnswer);
		user.setSecurityQuestion(securityQuestion);
		HttpSession session  = request.getSession(true);
		session.setAttribute("user", user);
		String str = rest.postForObject("http://localhost:8088/forgotPassword",user, String.class);
		return str;
		
		
	}
	
	@RequestMapping(value = "/Home", method = RequestMethod.POST,produces = "application/json")
	public String successfullChagePassword(HttpServletRequest request) {
		
		String password = request.getParameter("n3");
		String confirmPassword = request.getParameter("n4");
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		user.setPassword(password);
		
		if(password.equals(confirmPassword)) {
			
			String str = rest.postForObject("http://localhost:8088/passwordChangePage",user, String.class);
			return str;
					
		}
		
		return "ForgotPasswordConfirmation";
	}
	
	@RequestMapping(value="/SignUp", method = RequestMethod.POST, produces="application/json")
	public String validateSignUpDetails(HttpServletRequest request) {

		User user = new User();
		String email = request.getParameter("a1");
		user.setEmailId(email);
		String password = request.getParameter("a2");
		user.setPassword(password);
		String role = request.getParameter("a3");
		user.setRole(role);
		String securityQuestion = request.getParameter("a4");
		user.setSecurityQuestion(securityQuestion);
		String securityAnswer = request.getParameter("a5");
		user.setSecurityAnswer(securityAnswer);
		String str = rest.postForObject("http://localhost:8088/signUp", user, String.class);
		if(str.equals("ask")) {
			//set msg
		}
		return str;
	}
	
	@RequestMapping(value = "/Customer_OTP",method = RequestMethod.POST, produces="application/json")
	public String enterMoreSignUpDetailsCustomer(HttpServletRequest request) {
		
		Customer customer = new Customer();
		String name = request.getParameter("n2");
		String email = request.getParameter("n5");
		String mobileNo = request.getParameter("n4");
		String address = request.getParameter("n8");
		String pincode = request.getParameter("n6");
		customer.setCustomerAddress(address);
		customer.setCustomerEmail(email);
		customer.setCustomerMobileNumber(mobileNo);
		customer.setCustomerName(name);
		customer.setCustomerPincode(pincode);
		String str = rest.postForObject("http://localhost:8088/registerCustomer", customer, String.class);
		return str;
		
	}
	
	@RequestMapping(value = "/Merchant_OTP",method = RequestMethod.POST, produces="application/json")
	public String enterMoreSignUpDetailsMerchant(HttpServletRequest request) {
		
		Merchant merchant = new Merchant();
		String name = request.getParameter("n1");
		String email = request.getParameter("n2");
		String storeName = request.getParameter("n3");
		String mobileNo = request.getParameter("n4");
		String address = request.getParameter("n5");
		merchant.setMerchantAddress(address);
		merchant.setMerchantEmail(email);
		merchant.setMerchantMobileNumber(mobileNo);
		merchant.setMerchantName(name);
		merchant.setMerchantStoreName(storeName);
		String str = rest.postForObject("http://localhost:8088/registerMerchant", merchant, String.class);
		return str;
	}
			
	@RequestMapping(value = "/ChangePassword")
	public String getChangePasswordPage() {
		return "ChangePassword";
	}
		
	
	@RequestMapping("/logOut")
	public String logOut(HttpServletRequest request) {
		
		HttpSession session = request.getSession();
		session.invalidate();
		return "Home";
		
	}
}

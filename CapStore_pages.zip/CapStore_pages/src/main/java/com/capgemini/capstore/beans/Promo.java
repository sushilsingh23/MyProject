package com.capgemini.capstore.beans;

import java.util.Date;

public class Promo {
	
	private String promoCode;
	
	private double discountOffered;
	
	private Date promoValidity;
	
	private String softDelete;

	public String getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	public double getDiscountOffered() {
		return discountOffered;
	}

	public void setDiscountOffered(double discountOffered) {
		this.discountOffered = discountOffered;
	}

	public Date getPromoValidity() {
		return promoValidity;
	}

	public void setPromoValidity(Date promoValidity) {
		this.promoValidity = promoValidity;
	}

	public String getSoftDelete() {
		return softDelete;
	}

	public void setSoftDelete(String softDelete) {
		this.softDelete = softDelete;
	}

}

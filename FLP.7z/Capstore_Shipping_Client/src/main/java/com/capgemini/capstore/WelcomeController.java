package com.capgemini.capstore;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.User;

@Controller
public class WelcomeController {

	@RequestMapping("/")
	public String getResponse(){
		
		return "Home";
	}
	
	@GetMapping("/Login")
	public String getLoginPage(){
		
		return "Login";
	}
	
	@GetMapping("/Admin")
	public String getAdminPage(){
		
		return "Admin";
	}
	
	@GetMapping("/AllMerchants")
	public String getMerchantDetailsPage(ModelMap map){
		
		RestTemplate restTemplate = new RestTemplate();
		ArrayList<Merchant> list = (ArrayList)restTemplate.getForObject("http://localhost:8088/showallmerchants", ArrayList.class);
		map.addAttribute("list", list);
		return "AllMerchants";
	}
	
	@GetMapping("/CheckOrdersByAdmin")
	public String getPendingOrder(ModelMap map){
		
		RestTemplate restTemplate = new RestTemplate();
		ArrayList<Order> list = (ArrayList)restTemplate.getForObject("http://localhost:8088/CheckOrdersByAdmin", ArrayList.class);
		map.addAttribute("list", list);
		return "CheckOrdersByAdmin";
	}
	
	@GetMapping("/CheckOrdersByAdmin/{id}")
	public String getPendingOrder(@PathVariable String id,ModelMap map){
		
		RestTemplate restTemplate = new RestTemplate();
		System.out.println(id);
		int id1 = Integer.parseInt(id);
		ArrayList<Order> list = restTemplate.getForObject("http://localhost:8088/CheckOrdersByAdmin/"+id1, ArrayList.class);
		System.out.println("b");
		map.addAttribute("list", list);
		return "CheckOrdersByAdmin";
	}
	
	@RequestMapping(value="/HomeCustomer", method=RequestMethod.POST)
	public String getSignUp(HttpServletRequest request) {
		RestTemplate rest = new RestTemplate();
		User user = new User();
		String email = request.getParameter("email");
		user.setEmailId(email);
		user.setPassword(request.getParameter("password"));
		user.setRole("CUSTOMER");
		//user.setSecurityAnswer(securityAnswer);
		/*
		 * RestResponseUser restRes = new RestResponseUser(); restRes.setUser(user);
		 * ResponseUser resp = new ResponseUser(); resp.setRestResponseUser(restRes);
		 */String str = rest.postForObject("http://localhost:8088/logIn", user, String.class);
		return str;
	}
	
	@RequestMapping(value = "/Login", method = RequestMethod.POST)
	public void getSignUpDetails(@RequestBody User user) {
		
		
		
	}
	
//	@RequestMapping("/CustomerSignUpDone")
	
	
	
}

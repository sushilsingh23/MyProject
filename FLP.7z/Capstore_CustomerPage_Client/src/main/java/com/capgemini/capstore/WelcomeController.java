package com.capgemini.capstore;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.capgemini.capstore.beans.Order;

@Controller
public class WelcomeController {

	@RequestMapping("/")
	public String getResponse(){
		
		return "Home";
	}
	
	@RequestMapping("/MyOrders")
	public String getOrders(){
		
		return "MyOrders";
	}
	
	@RequestMapping(value="/orders", method= RequestMethod.GET)
	public String getOrdersDetailsPage(ModelMap map){
		RestTemplate restTemplate = new RestTemplate();
		List<Order> list = restTemplate.getForObject("http://localhost:8088/viewOrders/101", List.class);
		map.addAttribute("list", list);
		return "MyOrders";
	}
	
}

package com.capgemini.capstore;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.capgemini.capstore.beans.User;

@Controller
public class WelcomeController {

	@RequestMapping("/")
	public String getResponse() {

		return "Home";
	}

	@RequestMapping("/Ask")
	public String getResponseAsk() {

		return "Ask";
	}

	@RequestMapping("/CustomerSignUp")
	public String getLoginPage(HttpServletRequest request) {
		String email = request.getParameter("a1");
		System.out.println(email);
		User user = new User();

		RestTemplate rest = new RestTemplate();
		String page = rest.postForObject("http://localhost:8088/createCustomer",user,String.class);
		return page;
	}

	/*
	 * public String getCustomerHome(HttpServletRequest request) { // String return
	 * null; }
	 */

//	@RequestMapping("/CustomerSignUpDone")

}

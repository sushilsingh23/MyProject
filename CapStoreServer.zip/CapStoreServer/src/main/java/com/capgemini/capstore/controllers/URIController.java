package com.capgemini.capstore.controllers;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.User;
import com.capgemini.capstore.services.ICapStoreAdminService;
import com.capgemini.capstore.services.ICapStoreCommonService;
import com.capgemini.capstore.services.ICapStoreCustomerService;
import com.capgemini.capstore.services.ICapStoreMerchantService;

@RestController
public class URIController {

	@Autowired
	ICapStoreCommonService commonService;

	@Autowired
	ICapStoreAdminService adminService;

	@Autowired
	ICapStoreMerchantService merchantService;

	@Autowired
	ICapStoreCustomerService customerService;
	
	
	
	@RequestMapping("/")
	public String abc()
	{
		return "kuch bhi";
	}
	
	
	@RequestMapping(value = "/logIn", method = RequestMethod.POST)
	public String logIn(@RequestBody User user, HttpServletRequest request) {
		
		boolean result = false;
		try {
			
			result = commonService.ValidateLogIn(user);
			
			if(result) {
			
				HttpSession session = request.getSession(true);
				session.setAttribute("userId", user.getEmailId());
				session.setAttribute("role", user.getRole());
				
				if (user.getRole().equals("ADMIN")) {
					
					return "Admin";
					
				}
				if (user.getRole().equals("MERCHANT")) {
									
					return "MerchantHome";				
									
				}
				if (user.getRole().equals("CUSTOMER")) {
					
					return "HomeCustomer";
					
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		// set error msg
		return "Home";
	}

	@RequestMapping(value = "/logOut", method = RequestMethod.GET)
	public String logOut(HttpServletRequest request) {
		
		request.getSession().invalidate();
		return "indexPage";
		
	}

	@RequestMapping(value = "/forgotPassword", method = RequestMethod.POST)
	public String forgotPassword(@RequestBody User user, HttpServletRequest request) {
		
		User result = null;
		
		if ((result = commonService.isValidEmail(user.getEmailId())) != null) {
			
			if(user.getSecurityQuestion().equals(result.getSecurityQuestion()) && user.getSecurityAnswer().equals(result.getSecurityAnswer())) {
				
				return "ForgotPasswordConfirmation";
				
			}
			
		}
		
		return "ForgotPassword";
	}

	@RequestMapping(value = "/passwordChangePage", method = RequestMethod.POST)
	public String passwordChangePage(@RequestBody User user, HttpServletRequest request) {
		
		commonService.updatePassword(user.getEmailId(), user.getPassword());
		return "Home";
		
	}

	@RequestMapping(value = "/changePassword/{oldPassword}/{newPassword}", method = RequestMethod.PUT)
	public String changePassword(@PathVariable String oldPassword, @PathVariable String newPassword,
			HttpServletRequest request) {

		HttpSession session = request.getSession();
		
		if (session == null) {
			return "logIn page WIth Msg you need to log In first";
		}
		
		if (commonService.changePassword((String) session.getAttribute("userId"), oldPassword, newPassword)) {
			return "passwordChangeSuccessfully";
		}
		
		return "changePasswordwithErrorPage";
	}

	@RequestMapping(value = "/signUp", method = RequestMethod.POST)
	public String signUp(@Valid @RequestBody User user) {
		
		System.out.println("hello");
		System.out.println(user);
	
		if (commonService.ValidateUserDetails(user)) {
			if(user.getRole().equalsIgnoreCase("CUSTOMER"))
				return "CustomerSignUp";
			if(user.getRole().equalsIgnoreCase("MERCHANT"))
				return "MerchantSignUp";
		}
			// set error msg details are incorrect
			return "ask";
	}
	
	@RequestMapping(value = "/registerMerchant", method = RequestMethod.POST)
	public String finalRegistrationForMerchant(@RequestBody Merchant merchant) {
		merchant.setMerchantRating(1);
		merchant.setProducts(new ArrayList<Product>());
		System.out.println(merchant);
		merchantService.registerMerchant(merchant);
		
		return "Login";
		
	}

	@RequestMapping(value = "/registerCustomer", method = RequestMethod.POST)
	public String finalRegistrationForCustomer(@RequestBody Customer customer) {
		System.out.println(customer);
		merchantService.registerCustomer(customer);
		
		return "Login";
		
	}
	
}

package com.capgemini.capstore.controllers;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class CapStoreAdminController {

}

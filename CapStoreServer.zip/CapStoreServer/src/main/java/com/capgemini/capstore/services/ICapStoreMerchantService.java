package com.capgemini.capstore.services;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;

public interface ICapStoreMerchantService {

	void registerMerchant(Merchant merchant);

	void registerCustomer(Customer customer);

}
